BigDogs = {
    "a_c_chop",
    "a_c_husky",
    "a_c_retriever",
    "a_c_shepherd",
    "a_c_rottweiler",
}

SmallDogs = {
    "a_c_poodle",
    "a_c_pug",
    "a_c_westy",
}